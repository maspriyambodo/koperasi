<?php 
include '../h_tetap.php';
$kkbayar=$result->c_d($_POST['kkbayar']);
$produk=$result->c_d($_POST['produk']);
$umur=age(date_sql($result->c_d($_POST['tglahir'])));
$hasil=$result->query_y1("SELECT nmkb FROM kkb WHERE kd='$kkbayar' LIMIT 1");if($result->num($hasil)==0)die('Kantor Bayar Belum Terdaftar !');$row= $result->row($hasil);$nmbayar=$row['nmkb'];
$hasil=$result->query_y1("SELECT htagih FROM debit1 WHERE kdproduk='$produk' LIMIT 1");if($result->num($hasil)==0)die('Kode Produk Tidak Ditemukan');$row=$result->row($hasil);$kdkop=$row['htagih'];
$data = array(
	'nocitra' => $_POST['nocitra'],
	'noreks' => $_POST['noreks'],
	'nopen' => $_POST['nopen'],
	'noktp' => $_POST['noktp'],
	'tglahir' => date_sql($_POST['tglahir']),
	'pekerjaan' => $_POST['pekerjaan'],
	'umur' => $umur,
	'nmwaris' => $_POST['nmwaris'],
	'tglahirw' => date_sql($_POST['tglahirw']),
	'jenis' => $_POST['jenis'],
	'jenis1' => $_POST['jenis1'],
	'kdjiwa' => $_POST['kdjiwa'],
	'nokarip' => $_POST['nokarip'],
	'nodapem' => $_POST['nodapem'],
	'kdbyr' => $_POST['kdbyr'],
	'kkbayar' => $_POST['kkbayar'],
	'nmbayar' => $nmbayar,
	'deb1' => $_POST['deb1'],
	'tbunga' => $_POST['tbunga'],
	'flunas' => $_POST['flunas'],
	'kdpremi' => $_POST['kdpremi'],
	'kolek' => $_POST['kolek'],
	'ketkolek' => $_POST['ketkolek'],
	'ketnas' => $_POST['ketnas'],
	'kdgol' => $_POST['kdgol'],
	'kdjamin' => $_POST['kdjamin'],
	'kdsektor' => $_POST['kdsektor'],
	'jkredit' => $_POST['jkredit'],
	'skredit' => $_POST['skredit'],
	'kdguna' => $_POST['kdguna'],
	'gaji' => keangka($_POST['gaji']),
	'self1' => keangka($_POST['self1']),
	'self2' => keangka($_POST['self2']),
	'self3' => keangka($_POST['self3']),
	'pbank' => keangka($_POST['pbank']),
	'plain' => keangka($_POST['plain']),
	'kdsales' => $_POST['kdsales'],
	'arekom' => $_POST['arekom'],
	'nrekom' => $_POST['nrekom'],
	'trekom' => $_POST['trekom'],
	'lrekom' => $_POST['lrekom'],
	'krekom' => $_POST['krekom'],
	'brekom' => $_POST['brekom'],
	'nktprekom' => $_POST['nktprekom'],
	'tktprekom' => date_sql($_POST['tktprekom']),
	'nmsid' => $_POST['nmsid'],
	'produk' => $_POST['produk'],
	'kketnas' => $_POST['kketnas'],
	'kdkop' => $kdkop,
	'tgl_update' => date('Y-m-d H:i:s'),
	'user_update' => $userid,
  	'bussdate' => date('Y-m-d H:i:s')
);
$where = array('id' => $_POST['id']);
$result->update($tabel_kredit, $data, $where);
$data = array(
	'produk' => $_POST['produk'],
	'kdkop' => $kdkop,
);
$where = array('norek' => $_POST['norek']);
$result->update($tabel_payment, $data, $where);
echo 'Sukses Di Simpan...';
$result->close();$catat="Koreksi Data Kredit ".$_POST['id']. " Oleh ".$userid;
include '../around.php';
?>